start_ginkgo.bat			DOD batch to start the mindmap
start.bsh                  configuration setting for ginkgo
raoul_2014_08.db3 		database